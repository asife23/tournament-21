import React, { useState, useEffect } from "react";
import { Match, MatchSlot, GameName, MatchStatus, UserWallet, Transaction, GameCategory } from "../types";
import { TRANSLATIONS } from "../data";
import { 
  Trophy, 
  User, 
  Map, 
  Coins, 
  Compass, 
  ChevronRight, 
  Check, 
  Lock, 
  AlertCircle,
  X,
  Swords,
  Layers,
  Gamepad,
  CheckCircle2
} from "lucide-react";

interface MatchesViewProps {
  matches: Match[];
  wallet: UserWallet;
  onJoinMatch: (matchId: string, slotNo: number, ign: string) => void;
  lang: "bn" | "en";
  categories: GameCategory[];
}

export default function MatchesView({ matches, wallet, onJoinMatch, lang, categories }: MatchesViewProps) {
  const t = TRANSLATIONS[lang];
  
  // Game selectors
  const [selectedGame, setSelectedGame] = useState<string>(() => categories[0]?.name || "Free Fire");
  const [selectedStatus, setSelectedStatus] = useState<MatchStatus>("Upcoming");

  // Keep selectedGame inside dynamic categories list
  useEffect(() => {
    if (categories.length > 0 && !categories.some(c => c.name === selectedGame)) {
      setSelectedGame(categories[0].name);
    }
  }, [categories, selectedGame]);
  
  // Modal states
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<number | null>(null);
  const [gameUid, setGameUid] = useState<string>("");
  const [gameIgn, setGameIgn] = useState<string>("");
  const [bookingError, setBookingError] = useState<string>("");
  const [bookingSuccess, setBookingSuccess] = useState<boolean>(false);

  // Filter matches based on game tab and state status
  const filteredMatches = matches.filter(
    (m) => m.game === selectedGame && m.status === selectedStatus
  );

  const handleOpenBookingModal = (match: Match) => {
    setSelectedMatch(match);
    setSelectedSlot(null);
    setGameUid("");
    setGameIgn("");
    setBookingError("");
    setBookingSuccess(false);
  };

  const handleBookSlotCheck = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingError("");

    if (!selectedMatch) return;
    if (selectedSlot === null) {
      setBookingError(lang === "bn" ? "⚠️ দয়া করে একটি স্লট আসন নির্বাচন করুন!" : "⚠️ Please select a slot seat number!");
      return;
    }

    if (!gameUid.trim() || !gameIgn.trim()) {
      setBookingError(lang === "bn" ? "⚠️ ইউআইডি এবং ইন-গেম নেম (IGN) আবশ্যক!" : "⚠️ Game UID and In-Game Name are required!");
      return;
    }

    if (wallet.balance < selectedMatch.entryFee) {
      setBookingError(t.sufficientBalanceErr);
      return;
    }

    // Call propagation to parent state
    onJoinMatch(selectedMatch.id, selectedSlot, gameIgn.trim());
    setBookingSuccess(true);
    
    // Auto closing modal shortly
    setTimeout(() => {
      setSelectedMatch(null);
    }, 1500);
  };

  return (
    <div className="flex flex-col gap-6" id="matches_lobby_viewport">
      
      {/* 1. TOP GAME CATEGORIES CARDS (Dynamic list managed by admin) */}
      <div>
        <h3 className="text-xs font-mono font-bold uppercase tracking-widest text-slate-500 mb-3 flex items-center gap-1.5 ">
          <Gamepad className="w-3.5 h-3.5" />
          {t.gameCategories}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {categories.map((cat) => {
            const isActive = selectedGame === cat.name;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedGame(cat.name);
                }}
                className={`p-3.5 rounded-xl border text-center transition-all duration-300 relative overflow-hidden group cursor-pointer ${
                  isActive
                    ? "bg-indigo-600 border-indigo-500 shadow-md shadow-indigo-950/40 text-white"
                    : "bg-slate-900 border-slate-800 hover:border-slate-700/85 hover:bg-slate-950 text-slate-350"
                }`}
                id={`game_category_tab_${cat.id}`}
              >
                <span className="block text-2xl mb-1">{cat.icon}</span>
                <span className="block text-xs font-black tracking-tight">{cat.name}</span>
                <span className="block text-[9px] text-indigo-300 group-hover:text-white transition mt-0.5 font-medium">
                  {lang === "bn" ? cat.localName : "Enter Lobby →"}
                </span>
                
                {isActive && (
                  <div className="absolute right-0 bottom-0 bg-indigo-500 text-white p-0.5 rounded-l text-[8px] font-bold">
                    ACTIVE
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. MATCH STATUS TIMELINE SWITCH (Upcoming, Ongoing, Completed) */}
      <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800 w-fit self-center md:self-start">
        {[
          { id: "Upcoming" as const, text: t.upcoming, color: "active:bg-indigo-600" },
          { id: "Ongoing" as const, text: t.ongoing, color: "active:bg-amber-600" },
          { id: "Completed" as const, text: t.completed, color: "active:bg-emerald-600" }
        ].map((statusObj) => {
          const isActive = selectedStatus === statusObj.id;
          return (
            <button
              key={statusObj.id}
              onClick={() => setSelectedStatus(statusObj.id)}
              className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                isActive
                  ? "bg-slate-950 text-white border border-slate-800 shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {statusObj.text}
            </button>
          );
        })}
      </div>

      {/* 3. RESPONSIVE MATCH MATRIX DECK */}
      {filteredMatches.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-16 text-center text-slate-500" id="blank_matches_panel">
          <Swords className="w-12 h-12 text-slate-700 mx-auto mb-3 animate-pulse" />
          <p className="text-sm font-semibold">
            {lang === "bn" ? "❌ এই ক্যাটাগরিতে কোনো ম্যাচ রেকর্ড পাওয়া যায়নি।" : "❌ No matches scheduled in this section."}
          </p>
          <p className="text-xs text-slate-600 mt-1">
            {lang === "bn" ? "দয়া করে অন্য গেম বা ক্যাটাগরি ট্রাই করুন।" : "Try another tab or create a customized match via the Admin menu."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="matches_viewport_matrix">
          {filteredMatches.map((match) => {
            // Count spots filled
            const bookedCount = match.slots.filter(s => s.isBooked).length;
            const slotsLeft = match.totalSlots - bookedCount;
            const isFull = slotsLeft <= 0;

            return (
              <div
                key={match.id}
                className="bg-slate-900 rounded-2xl border border-slate-800 p-5 flex flex-col justify-between hover:border-slate-700/80 transition-all duration-300 relative overflow-hidden group shadow"
                id={`match_card_${match.id}`}
              >
                {/* Glow outline decoration */}
                <div className="absolute top-0 inset-x-0 h-[1.5px] bg-indigo-500/0 group-hover:bg-gradient-to-r group-hover:from-indigo-500 group-hover:to-cyan-400 transition-all duration-300"></div>

                <div>
                  {/* Top bar with map and mode badges */}
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-3">
                    <span className="flex items-center gap-1 bg-slate-950 px-2 py-0.5 rounded border border-slate-850">
                      <Map className="w-3.5 h-3.5 text-slate-500" />
                      {match.map}
                    </span>
                    <span className="bg-indigo-500/10 text-indigo-400 font-bold px-2 py-0.5 rounded border border-indigo-500/15">
                      {match.type}
                    </span>
                  </div>

                  {/* Title */}
                  <h4 className="text-sm font-black text-white leading-snug group-hover:text-indigo-300 transition duration-200">
                    #{match.matchNum} - {match.title}
                  </h4>

                  <p className="text-[10px] font-mono text-slate-400 mt-1.5 flex items-center gap-1 bg-slate-950/60 p-1 rounded w-fit text-left">
                    🗓️ {match.dateTime}
                  </p>

                  {/* Financial terms card details */}
                  <div className="grid grid-cols-3 gap-2 bg-slate-950 border border-slate-850 rounded-xl p-3 mt-4 text-center">
                    <div>
                      <span className="block text-[9px] font-mono text-slate-500 uppercase">{t.prizePool}</span>
                      <span className="block text-xs font-extrabold text-yellow-400 font-mono mt-0.5">🪙 {match.prizePool}</span>
                    </div>
                    <div>
                      <span className="block text-[9px] font-mono text-slate-500 uppercase">{t.entryFee}</span>
                      <span className="block text-xs font-extrabold text-white font-mono mt-0.5">🪙 {match.entryFee}</span>
                    </div>
                    <div>
                      <span className="block text-[9px] font-mono text-slate-500 uppercase">{t.perKill}</span>
                      <span className="block text-xs font-extrabold text-red-400 font-mono mt-0.5">
                        {match.perKill > 0 ? `🪙 ${match.perKill}` : "N/A"}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Slots fill counts & actions */}
                <div className="mt-5 pt-3.5 border-t border-slate-800/80 flex flex-col gap-3">
                  {match.status === "Upcoming" && (
                    <>
                      <div className="flex items-center justify-between text-[11px] font-mono">
                        <span className="text-slate-400 uppercase">Seats / Slots</span>
                        <span className={`font-bold ${isFull ? "text-red-400" : "text-emerald-400"}`}>
                          {isFull 
                            ? t.fullBtn 
                            : `${slotsLeft} ${t.slotsLeft} (${bookedCount}/${match.totalSlots})`
                          }
                        </span>
                      </div>
                      
                      {/* Slots Progress bar */}
                      <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-850">
                        <div 
                          className="h-full bg-gradient-to-r from-indigo-500 to-indigo-400 transition-all duration-300" 
                          style={{ width: `${(bookedCount / match.totalSlots) * 100}%` }}
                        ></div>
                      </div>

                      <button
                        onClick={() => handleOpenBookingModal(match)}
                        disabled={isFull}
                        className="w-full mt-1.5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-400 text-xs font-bold text-white rounded-xl shadow-md cursor-pointer transition flex items-center justify-center gap-1 disabled:cursor-not-allowed"
                      >
                        <Coins className="w-3.5 h-3.5 text-yellow-300" />
                        {t.joinBtn}
                      </button>
                    </>
                  )}

                  {match.status === "Ongoing" && (
                    <div className="flex flex-col gap-2">
                      <span className="text-amber-500 font-bold block text-center uppercase tracking-wide flex items-center justify-center gap-1 text-[10px]">
                        <span className="w-2 h-2 bg-amber-500 rounded-full animate-ping"></span>
                        {lang === "bn" ? "খেলা চলছে / লাইভ" : "Match is Live!"}
                      </span>
                      <button
                        onClick={() => handleOpenBookingModal(match)}
                        className="w-full py-2 bg-slate-950 hover:bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300 rounded-xl transition"
                      >
                        🔑 {t.roomCredentials}
                      </button>
                    </div>
                  )}

                  {match.status === "Completed" && (
                    <button
                      onClick={() => handleOpenBookingModal(match)}
                      className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white rounded-xl border border-slate-750 transition flex items-center justify-center gap-1.5"
                    >
                      👑 {lang === "bn" ? "ফলাফল ও লিডারবোর্ড দেখুন" : "View Match Standings"}
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* ==================== 4. MATCH SLOTS BOOKING OVERLAY MODAL ==================== */}
      {selectedMatch && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div 
            className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto flex flex-col p-6 animate-fadeIn text-xs shadow-2xl relative"
            id="match_lobby_modal"
          >
            {/* Close */}
            <button
              onClick={() => setSelectedMatch(null)}
              className="absolute top-4 right-4 p-2 bg-slate-950 hover:bg-slate-800 rounded-full border border-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header info */}
            <div className="border-b border-slate-800/80 pb-4 mb-5 flex flex-col gap-1.5 pr-8 text-left">
              <span className="text-[9px] font-mono text-indigo-400 uppercase tracking-widest font-black">
                {selectedMatch.game} MATCH LOBBY
              </span>
              <h3 className="text-base font-extrabold text-white">
                #{selectedMatch.matchNum} - {selectedMatch.title}
              </h3>
              <p className="text-[10px] text-slate-500 font-mono">
                🗓️ {selectedMatch.dateTime} | Map: {selectedMatch.map}
              </p>
            </div>

            {/* UPCOMING FLOW - SEAT SELECTION & REGISTRATION FORM */}
            {selectedMatch.status === "Upcoming" && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 text-left">
                
                {/* INTERACTIVE SEATING SELECTION FIELD (COL 7) */}
                <div className="md:col-span-7 flex flex-col gap-3">
                  <h4 className="text-[11px] font-mono tracking-wider font-bold text-slate-400 uppercase">
                    🛎️ Select Slot Seat Number: {selectedSlot && <span className="text-yellow-400 font-extrabold bg-slate-950 px-2 py-0.5 rounded font-mono border border-slate-850">Slot #{selectedSlot}</span>}
                  </h4>
                  
                  {/* Seating map grid (responsive 6x8 for 48, 2x4 for 8, 2x2 for 4) */}
                  <div className={`grid gap-2 p-3 bg-slate-950 border border-slate-850/80 rounded-2xl max-h-[280px] overflow-y-auto p-1.5 ${
                    selectedMatch.totalSlots === 48 
                      ? "grid-cols-6" 
                      : (selectedMatch.totalSlots === 8 ? "grid-cols-4" : "grid-cols-2")
                  }`}>
                    {selectedMatch.slots.map((slot) => {
                      const isBooked = slot.isBooked;
                      const isChosen = selectedSlot === slot.slotNo;

                      return (
                        <button
                          key={slot.slotNo}
                          type="button"
                          disabled={isBooked}
                          onClick={() => {
                            setSelectedSlot(slot.slotNo);
                            setBookingError("");
                          }}
                          className={`h-11 rounded-lg flex flex-col items-center justify-center font-mono text-[10px] font-bold border transition-all cursor-pointer select-none active:scale-95 ${
                            isBooked
                              ? "bg-rose-950/20 border-rose-500/25 text-rose-400/50 line-through cursor-not-allowed"
                              : isChosen
                              ? "bg-indigo-600 border-indigo-500 text-white font-black scale-102 shadow-lg shadow-indigo-600/30"
                              : "bg-slate-900 border-slate-800 text-slate-350 hover:border-indigo-500 hover:text-indigo-300"
                          }`}
                          title={isBooked ? `Booked by ${slot.registeredBy}` : `Free slot #${slot.slotNo}`}
                        >
                          <span className="block text-[8px] opacity-60">Seat</span>
                          <span>{slot.slotNo}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* SQUAD JOIN FORM (COL 5) */}
                <form onSubmit={handleBookSlotCheck} className="md:col-span-5 flex flex-col gap-3.5">
                  <h4 className="text-[11px] font-mono tracking-wider font-bold text-slate-400 uppercase">
                    📝 Competitor Registration
                  </h4>

                  <div className="bg-slate-950/80 border border-slate-850 rounded-xl p-3 flex flex-col gap-1 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Wallet Balance:</span>
                      <span className="font-bold text-white font-mono">🪙 {wallet.balance} Coins</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-900 pt-1 mt-1">
                      <span className="text-slate-400">Match Entry Fee:</span>
                      <span className="font-extrabold text-yellow-400 font-mono">🪙 {selectedMatch.entryFee} Coins</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">{t.gameUidLabel}</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., 543729938"
                      value={gameUid}
                      onChange={(e) => setGameUid(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">{t.gameIgnLabel}</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Boss_Rifat"
                      value={gameIgn}
                      onChange={(e) => setGameIgn(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none"
                    />
                  </div>

                  {bookingError && (
                    <div className="bg-rose-500/10 border border-rose-500/25 text-rose-400 p-2.5 rounded-lg text-[10px]">
                      {bookingError}
                    </div>
                  )}

                  {bookingSuccess && (
                    <div className="bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 p-2.5 rounded-lg text-[11px] font-bold text-center flex items-center justify-center gap-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 animate-pulse" />
                      Slot Booked Successfully!
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full mt-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg transition-colors cursor-pointer text-xs uppercase tracking-wide"
                  >
                    🚀 {t.submitBooking}
                  </button>
                </form>

              </div>
            )}

            {/* ONGOING FLOW - ROOM ID DISPLAY */}
            {selectedMatch.status === "Ongoing" && (
              <div className="flex flex-col gap-4 text-center items-center py-6">
                <Lock className="w-12 h-12 text-amber-500 animate-pulse mb-2" />
                
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">{t.roomCredentials}</h4>
                <p className="text-xs text-slate-400 max-w-sm">
                  {selectedMatch.roomId ? (
                    lang === "bn" 
                      ? "পাসওয়ার্ড ও রুম আইডি নিচে দেওয়া হলো। কাউকে শেয়ার করবেন না।" 
                      : "The custom game lobby credentials are shown below. Sharing will result in immediate disqualification."
                  ) : t.noRoomCredentials}
                </p>

                {selectedMatch.roomId ? (
                  <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 w-full max-w-md font-mono mt-4 flex flex-col gap-3 shadow">
                    <div className="flex justify-between items-center bg-slate-900 px-4 py-2.5 rounded-xl">
                      <span className="text-slate-500 text-xs uppercase font-sans">Room ID</span>
                      <span className="text-base font-extrabold text-white text-indigo-400">{selectedMatch.roomId}</span>
                    </div>

                    <div className="flex justify-between items-center bg-slate-900 px-4 py-2.5 rounded-xl">
                      <span className="text-slate-500 text-xs uppercase font-sans">Password</span>
                      <span className="text-base font-extrabold text-white text-emerald-400">{selectedMatch.roomPass}</span>
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-950 p-4 border border-indigo-500/10 rounded-xl text-indigo-300 font-semibold text-xs mt-4">
                    ⚠️ {lang === "bn" ? "রুম আইডি জেনারেট হওয়ার অপেক্ষায় রয়েছে।" : "Room ID is waiting to be shared by Host Admin."}
                  </div>
                )}
              </div>
            )}

            {/* COMPLETED FLOW - STANDINGS & RESULTS AND PRIZES WON */}
            {selectedMatch.status === "Completed" && (
              <div className="flex flex-col gap-4 py-2">
                <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-[#FFD700] mb-2 text-center flex items-center justify-center gap-1">
                  ⚔️ MATCH END RESULTS & PAYOUTS
                </h4>

                {selectedMatch.results && selectedMatch.results.length > 0 ? (
                  <div className="bg-slate-950 border border-slate-850 rounded-2xl overflow-hidden font-mono text-left">
                    <div className="grid grid-cols-12 gap-2 p-3 bg-slate-900 border-b border-slate-850 text-[10px] uppercase font-bold text-slate-400 text-center">
                      <div className="col-span-2 text-left">Rank</div>
                      <div className="col-span-4 text-left">Player Tag</div>
                      <div className="col-span-3">Kills</div>
                      <div className="col-span-3 text-right">Prize Cash</div>
                    </div>

                    <div className="divide-y divide-slate-850/60 font-mono">
                      {selectedMatch.results.map((res, i) => (
                        <div key={res.playerIgn} className="grid grid-cols-12 gap-2 items-center p-3 text-xs">
                          <div className="col-span-2 font-black text-slate-300 flex items-center gap-1">
                            {res.rank === 1 ? "🥇" : res.rank === 2 ? "🥈" : "🥉"}
                            {res.rank}
                          </div>
                          <div className="col-span-4 font-bold text-white truncate max-w-[150px] font-sans">
                            {res.playerIgn}
                          </div>
                          <div className="col-span-3 text-center text-red-400 flex items-center justify-center gap-0.5">
                            💥 {res.kills}
                          </div>
                          <div className="col-span-3 text-right text-yellow-400 font-extrabold font-mono">
                            🪙 {res.prizeWon}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-950 p-6 border border-slate-850 rounded-2xl text-center text-slate-500">
                    {lang === "bn" ? "ভেরিফিকেশন চলছে! এডমিন শীঘ্রই ফলাফল প্রকাশ করবেন।" : "Verification in progress! Results will be published by admin shortly."}
                  </div>
                )}
              </div>
            )}

            {/* RULES SECTION CARDS */}
            <div className="border-t border-slate-800/80 mt-6 pt-5 text-left">
              <h4 className="text-[11px] font-mono tracking-wider font-bold text-slate-400 uppercase mb-2 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-indigo-400" />
                {t.rulesTitle}
              </h4>
              <ul className="space-y-1.5 text-[11px] text-slate-400 font-sans">
                <li>{t.rule1}</li>
                <li>{t.rule2}</li>
                <li>{t.rule3}</li>
              </ul>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
