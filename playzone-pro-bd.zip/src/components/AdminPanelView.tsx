import React, { useState, useEffect } from "react";
import { Match, Transaction, GameName, TeamType, GameCategory } from "../types";
import { TRANSLATIONS } from "../data";
import { 
  Plus, 
  Check, 
  X, 
  Award, 
  DollarSign, 
  Sparkles, 
  Calendar,
  Layers,
  Map,
  Trophy,
  AlertCircle,
  Gamepad
} from "lucide-react";

interface AdminPanelViewProps {
  matches: Match[];
  transactions: Transaction[];
  onAddMatch: (match: Match) => void;
  onApproveTransaction: (id: string, approve: boolean) => void;
  onDeclareResults: (matchId: string, results: { rank: number; playerIgn: string; kills: number; prizeWon: number }[]) => void;
  lang: "bn" | "en";
  categories: GameCategory[];
  onAddCategory: (category: GameCategory) => void;
  onDeleteCategory: (id: string) => void;
}

export default function AdminPanelView({
  matches,
  transactions,
  onAddMatch,
  onApproveTransaction,
  onDeclareResults,
  lang,
  categories,
  onAddCategory,
  onDeleteCategory
}: AdminPanelViewProps) {
  const t = TRANSLATIONS[lang];
  
  // Create Match form states
  const [newGame, setNewGame] = useState<string>(() => categories[0]?.name || "Free Fire");
  const [newTitle, setNewTitle] = useState("");
  const [newPrize, setNewPrize] = useState("500");
  const [newFee, setNewFee] = useState("20");
  const [newPerKill, setNewPerKill] = useState("5");
  const [newMap, setNewMap] = useState("Bermuda");
  const [newType, setNewType] = useState<TeamType>("Solo");
  const [dateTime, setDateTime] = useState("Today, 09:00 PM");
  const [newSlots, setNewSlots] = useState("48");

  // Synchronize newGame default if category changes
  useEffect(() => {
    if (categories.length > 0 && !categories.some(c => c.name === newGame)) {
      setNewGame(categories[0].name);
    }
  }, [categories, newGame]);

  // Results declaration states
  const [selMatchId, setSelMatchId] = useState("");
  const [winnerIgn, setWinnerIgn] = useState("");
  const [winnerKills, setWinnerKills] = useState("6");
  const [runnerIgn, setRunnerIgn] = useState("");
  const [runnerKills, setRunnerKills] = useState("4");

  const [creatorMsg, setCreatorMsg] = useState("");
  const [resultsMsg, setResultsMsg] = useState("");

  const handleCreateMatch = (e: React.FormEvent) => {
    e.preventDefault();
    setCreatorMsg("");

    if (!newTitle.trim()) {
      alert(lang === "bn" ? "ম্যাচের একটি আকর্ষণীয় নাম দিন!" : "Match Title required!");
      return;
    }

    const prizeNum = parseInt(newPrize) || 0;
    const feeNum = parseInt(newFee) || 0;
    const perKillNum = parseInt(newPerKill) || 0;
    const maxSlots = parseInt(newSlots) || 48;

    const newMatchObj: Match = {
      id: `match-${Date.now()}`,
      game: newGame,
      matchNum: Math.floor(Math.random() * 900) + 100,
      dateTime,
      title: newTitle.trim(),
      prizePool: prizeNum,
      entryFee: feeNum,
      perKill: perKillNum,
      version: "Mobile",
      map: newMap || "Classic map",
      type: newType,
      totalSlots: maxSlots,
      status: "Upcoming",
      slots: Array.from({ length: maxSlots }, (_, i) => ({
        slotNo: i + 1,
        gameId: `match-${Date.now()}`,
        gameName: newGame,
        isBooked: false,
      })),
    };

    onAddMatch(newMatchObj);
    setCreatorMsg(lang === "bn" ? "🎉 ম্যাচ সফলভাবে পাবলিশ হয়েছে!" : "🎉 Custom Match successfully created!");
    setNewTitle("");
  };

  const pendingDeposits = transactions.filter(t => t.status === "Pending");

  const handleDeclareWinnerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setResultsMsg("");

    if (!selMatchId) {
      alert(lang === "bn" ? "অনুগ্রহ করে একটি ম্যাচ সিলেক্ট করুন!" : "Please select a match first!");
      return;
    }

    if (!winnerIgn.trim()) {
      alert(lang === "bn" ? "বিজয়ীর নাম দিন!" : "Winner IGN is required!");
      return;
    }

    // Distribute custom prize pools:
    // Rank 1 wins 60% of prizePool, Rank 2 wins 40% + (kills * perKill)
    const matchObj = matches.find(m => m.id === selMatchId);
    if (!matchObj) return;

    const winKills = parseInt(winnerKills) || 0;
    const runKills = parseInt(runnerKills) || 0;

    const winPrize = Math.floor(matchObj.prizePool * 0.6) + (winKills * matchObj.perKill);
    const runPrize = Math.floor(matchObj.prizePool * 0.4) + (runKills * matchObj.perKill);

    const calculatedResults = [
      { rank: 1, playerIgn: winnerIgn.trim(), kills: winKills, prizeWon: winPrize },
    ];

    if (runnerIgn.trim()) {
      calculatedResults.push({
        rank: 2,
        playerIgn: runnerIgn.trim(),
        kills: runKills,
        prizeWon: runPrize,
      });
    }

    onDeclareResults(selMatchId, calculatedResults);
    setResultsMsg(lang === "bn" ? "🎉 ফলাফল ঘোষিত হয়েছে ও খেলোয়াড়দের ওয়ালেটে টাকা এড হয়েছে!" : "🎉 Game Results published & coins dispatched to competitors!");
    setWinnerIgn("");
    setRunnerIgn("");
    setSelMatchId("");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-xs font-sans" id="admin_tab_root_control_deck">
      
      {/* 1. LEFT COLUMN RECHARGE REQUESTS (5 COLS) */}
      <div className="lg:col-span-5 flex flex-col gap-6" id="admin_approval_feed">
        
        {/* PENDING DEPOSIT TABLE */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2 border-b border-slate-800 pb-3 uppercase tracking-wider">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            {t.walletApprovals} ({pendingDeposits.length})
          </h3>

          {pendingDeposits.length === 0 ? (
            <div className="p-8 text-center text-slate-500 font-mono">
              ✔️ {t.noPendingDeposits}
            </div>
          ) : (
            <div className="flex flex-col gap-3 max-h-[400px] overflow-y-auto">
              {pendingDeposits.map((trx) => (
                <div 
                  key={trx.id}
                  className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col gap-2 relative overflow-hidden"
                  id={`pending_card_${trx.id}`}
                >
                  <div className="flex justify-between items-center bg-slate-900/60 p-1.5 rounded text-[10px]">
                    <span className="font-bold text-amber-500 uppercase font-mono">{trx.type}</span>
                    <span className="text-slate-500 font-mono text-[9px]">{trx.date}</span>
                  </div>

                  <div className="flex justify-between items-center mt-1">
                    <div className="text-left font-mono">
                      <p className="text-slate-400">Method: <span className="text-white font-extrabold">{trx.method}</span></p>
                      <p className="text-slate-400 mt-0.5">Phone: <span className="text-indigo-400 font-semibold">{trx.number}</span></p>
                      {trx.trxId && (
                        <p className="text-slate-400 mt-0.5">TrxID: <span className="text-emerald-400 font-mono font-bold uppercase">{trx.trxId}</span></p>
                      )}
                    </div>

                    <div className="text-right">
                      <span className="block text-base font-black text-white font-mono">
                        🪙 {trx.amount}
                      </span>
                    </div>
                  </div>

                  {/* APPROVE AND REJECT BUTTON ACTIONS */}
                  <div className="flex gap-2.5 mt-3 pt-2 border-t border-slate-800/80">
                    <button
                      onClick={() => onApproveTransaction(trx.id, true)}
                      className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      <Check className="w-3.5 h-3.5" />
                      {t.approveBtn}
                    </button>
                    <button
                      onClick={() => onApproveTransaction(trx.id, false)}
                      className="flex-1 py-2 bg-rose-950/40 hover:bg-rose-900 border border-rose-500/30 text-rose-300 font-bold rounded-lg flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                      {t.rejectBtn}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* CREATE MATCH CARD */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2 border-b border-slate-800 pb-3 uppercase tracking-wider">
            <Plus className="w-4 h-4 text-indigo-400" />
            {t.createMatch}
          </h3>

          <form onSubmit={handleCreateMatch} className="flex flex-col gap-3.5">
            <div>
              <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">Select Game Target</label>
              <select
                value={newGame}
                onChange={(e) => setNewGame(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700/80 rounded-lg p-2.5 outline-none font-bold text-white uppercase font-mono text-[11px]"
              >
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.name}>
                    {cat.name} {cat.localName ? `(${cat.localName})` : ""}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">Match Theme Title</label>
              <input
                type="text"
                required
                placeholder="e.g., Star Bermuda Mega Clash Series"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-lg p-2 text-white outline-none"
              />
            </div>

            <div className="grid grid-cols-3 gap-2 font-mono">
              <div>
                <label className="block text-slate-400 text-[9px] uppercase mb-1">Prize (Coins)</label>
                <input
                  type="number"
                  required
                  value={newPrize}
                  onChange={(e) => setNewPrize(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-center text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 text-[9px] uppercase mb-1">Entry (Coins)</label>
                <input
                  type="number"
                  required
                  value={newFee}
                  onChange={(e) => setNewFee(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-center text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 text-[9px] uppercase mb-1">Per Kill (Coins)</label>
                <input
                  type="number"
                  required
                  value={newPerKill}
                  disabled={newGame.includes("Ludo")}
                  onChange={(e) => setNewPerKill(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-center text-white disabled:opacity-40"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 font-mono">
              <div>
                <label className="block text-slate-400 text-[9px] uppercase mb-1">Battle Map</label>
                <input
                  type="text"
                  placeholder="Bermuda"
                  value={newMap}
                  onChange={(e) => setNewMap(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white text-[11px]"
                />
              </div>

              <div>
                <label className="block text-slate-400 text-[9px] uppercase mb-1">Team Mode</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as TeamType)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-bold text-[11px]"
                >
                  <option value="Solo">Solo</option>
                  <option value="Duo">Duo</option>
                  <option value="Squad">Squad</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 text-[9px] uppercase mb-1">Total Slots</label>
                <input
                  type="number"
                  required
                  value={newSlots}
                  onChange={(e) => setNewSlots(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-center text-white text-[11px]"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">Date & Time Target</label>
              <input
                type="text"
                value={dateTime}
                onChange={(e) => setDateTime(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
              />
            </div>

            {creatorMsg && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-2.5 rounded-lg text-center font-bold">
                {creatorMsg}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-bold text-white shadow shadow-indigo-600/20 flex items-center justify-center gap-1.5 cursor-pointer text-xs transition duration-200"
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              {t.createMatchBtn}
            </button>
          </form>
        </div>

        {/* GAME CATEGORIES MANAGER */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2 border-b border-slate-800 pb-3 uppercase tracking-wider">
            <Gamepad className="w-4 h-4 text-indigo-400" />
            {lang === "bn" ? "গেম ক্যাটাগরি ম্যানেজার" : "Game Categories Panel"}
          </h3>

          <div className="flex flex-col gap-2 mb-4 max-h-[180px] overflow-y-auto pr-1">
            {categories.map((cat) => (
              <div key={cat.id} className="flex justify-between items-center bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{cat.icon}</span>
                  <div>
                    <span className="block text-white font-black text-[11px] leading-none">{cat.name}</span>
                    <span className="block text-[8px] text-slate-500 mt-1 font-semibold">{cat.localName}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (confirm(lang === "bn" ? `আপনি কি '${cat.name}' গেমটি ডিলিট করতে চান?` : `Are you sure you want to delete '${cat.name}'?`)) {
                      onDeleteCategory(cat.id);
                    }
                  }}
                  className="p-1 px-2.5 bg-rose-950/30 border border-rose-500/10 text-rose-400 hover:bg-rose-900/60 rounded font-bold text-[9px] cursor-pointer transition-colors"
                >
                  {lang === "bn" ? "ডিলিট" : "Delete"}
                </button>
              </div>
            ))}
          </div>

          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const gameNameVal = (formData.get("gameName") as string || "").trim();
            const gameLocalVal = (formData.get("gameLocalName") as string || "").trim();
            const gameIconVal = (formData.get("gameIcon") as string || "").trim() || "🎮";

            if (!gameNameVal) return;

            onAddCategory({
              id: `game-${Date.now()}`,
              name: gameNameVal,
              localName: gameLocalVal || gameNameVal,
              icon: gameIconVal
            });

            e.currentTarget.reset();
          }} className="flex flex-col gap-2.5 pt-3 border-t border-slate-800">
            <p className="text-indigo-400 font-bold text-[9px] uppercase tracking-wide">{lang === "bn" ? "নতুন গেম যুক্ত করুন" : "Add Custom Game Category"}</p>
            
            <div className="grid grid-cols-12 gap-2">
              <div className="col-span-3">
                <label className="text-[8px] text-slate-500 font-mono block mb-1">Emoji</label>
                <input
                  name="gameIcon"
                  type="text"
                  maxLength={4}
                  defaultValue="🎮"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-center text-white font-extrabold"
                />
              </div>
              <div className="col-span-9">
                <label className="text-[8px] text-slate-500 font-mono block mb-1">Title (English)</label>
                <input
                  name="gameName"
                  type="text"
                  required
                  placeholder="e.g. Mobile Legends"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-bold outline-none placeholder:text-slate-700"
                />
              </div>
            </div>

            <div>
              <label className="text-[8px] text-slate-500 font-mono block mb-1">Bangla Label (বাংলা নাম)</label>
              <input
                name="gameLocalName"
                type="text"
                placeholder="যেমন: মোবাইল লেজেন্ডস"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none placeholder:text-slate-700"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-black text-[10px] tracking-wider flex items-center justify-center gap-1 cursor-pointer transition-colors"
            >
              <Plus className="w-3.5 h-3.5 text-yellow-300" />
              {lang === "bn" ? "গেম ক্যাটাগরি পাবলিশ করুন" : "Publish Game Category"}
            </button>
          </form>
        </div>

      </div>

      {/* 2. RIGHT COLUMN DISPATCH EARNINGS AND MATCHES STATUSES (7 COLS) */}
      <div className="lg:col-span-7 flex flex-col gap-6" id="admin_results_feed">
        
        {/* DECLARE RESULTS FEED */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2 border-b border-slate-800 pb-3 uppercase tracking-wider">
            <Award className="w-4 h-4 text-yellow-400 animate-pulse" />
            {t.submitMatchResults}
          </h3>

          <form onSubmit={handleDeclareWinnerSubmit} className="flex flex-col gap-4">
            
            {/* SELECT ACTIVE ONGOING/UPCOMING GAME */}
            <div>
              <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1.5">{t.selectMatchToFinalize}</label>
              <select
                value={selMatchId}
                onChange={(e) => setSelMatchId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 outline-none font-bold"
              >
                <option value="">-- {lang === "bn" ? "ম্যাচ সিলেক্ট করুন" : "Select Match"} --</option>
                {matches
                  .filter((m) => m.status !== "Completed")
                  .map((m) => (
                    <option key={m.id} value={m.id}>
                      #{m.matchNum} - {m.title} ({m.game})
                    </option>
                  ))
                }
              </select>
            </div>

            {/* RESULTS DETAILS FOR HIGH PLACEMENT */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/60 p-4 border border-slate-800 rounded-xl">
              
              <div className="flex flex-col gap-3">
                <span className="text-[10px] font-mono tracking-widest text-[#FFD700] uppercase font-black">🏆 1st Winner (Gold Rank)</span>
                <div>
                  <label className="block text-slate-400 mb-1">Winner In-Game Name (IGN)</label>
                  <input
                    type="text"
                    placeholder="e.g., Boss_Rifat"
                    value={winnerIgn}
                    onChange={(e) => setWinnerIgn(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-850 p-2 rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Total Winner Kills</label>
                  <input
                    type="number"
                    value={winnerKills}
                    onChange={(e) => setWinnerKills(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-850 p-2 rounded text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-3 border-t md:border-t-0 md:border-l border-slate-800 md:pl-4 pt-4 md:pt-0">
                <span className="text-[10px] font-mono tracking-widest text-[#C0C0C0] uppercase font-black">🥈 2nd Winner (Silver Rank)</span>
                <div>
                  <label className="block text-slate-400 mb-1">Runner IGN (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g., SkyBD_Fire"
                    value={runnerIgn}
                    onChange={(e) => setRunnerIgn(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-850 p-2 rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Runner Kills</label>
                  <input
                    type="number"
                    value={runnerKills}
                    onChange={(e) => setRunnerKills(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-850 p-2 rounded text-white font-mono"
                  />
                </div>
              </div>

            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 leading-relaxed text-slate-400 text-[10.5px]">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                <p>
                  <strong>Result Formula Details:</strong> 1st place wins 60% of the tournament Prize pool. 2nd place wins 40%. Additionally, both players will earn extra payouts calculated from their Kill Count: <code>kills * Per-Kill prize BDT.</code> Matches are instantly marked as completed.
                </p>
              </div>
            </div>

            {resultsMsg && (
              <div className="bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 p-3 rounded-xl text-center font-bold">
                {resultsMsg}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg shadow-emerald-600/15 flex items-center justify-center gap-1.5 cursor-pointer text-xs transition duration-200"
            >
              <Trophy className="w-4 h-4 text-yellow-300 animate-pulse" />
              {t.distributePrizes}
            </button>
          </form>
        </div>

        {/* RECENT BATTLES LOG SUMMARY SCREEN */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-800 pb-3 mb-4 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            {lang === "bn" ? "সক্রিয় ম্যাচের তালিকা" : "Published Game Matches"} ({matches.length})
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[300px] overflow-y-auto pr-1">
            {matches.map((m) => (
              <div 
                key={m.id}
                className="bg-slate-950 p-3 rounded-xl border border-slate-850 flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-center text-[10px] mb-1">
                    <span className="font-mono text-indigo-300 font-bold uppercase">{m.game}</span>
                    <span className={`px-1.5 py-0.2 rounded font-mono font-bold ${
                      m.status === "Completed"
                        ? "bg-emerald-500/10 text-emerald-400"
                        : m.status === "Ongoing"
                        ? "bg-amber-500/10 text-amber-500 animate-pulse"
                        : "bg-indigo-500/10 text-indigo-400"
                    }`}>
                      {m.status}
                    </span>
                  </div>
                  <h4 className="text-white font-bold leading-tight truncate mt-1">#{m.matchNum} - {m.title}</h4>
                  <p className="text-slate-500 text-[10px] font-mono mt-1 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-600" />
                    {m.dateTime}
                  </p>
                </div>

                <div className="flex justify-between items-center mt-3 pt-2 border-t border-slate-900 font-mono text-[10px]">
                  <span className="text-slate-400">Entry: <span className="text-slate-200">🪙 {m.entryFee} C</span></span>
                  <span className="text-slate-400">Prize: <span className="text-yellow-400">🪙 {m.prizePool} C</span></span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
