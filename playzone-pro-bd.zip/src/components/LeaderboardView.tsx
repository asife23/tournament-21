import React from "react";
import { LeaderboardUser } from "../types";
import { TRANSLATIONS } from "../data";
import { 
  Trophy, 
  Swords, 
  Award, 
  Target, 
  TrendingUp,
  Flame
} from "lucide-react";

interface LeaderboardViewProps {
  leaderboard: LeaderboardUser[];
  lang: "bn" | "en";
}

export default function LeaderboardView({ leaderboard, lang }: LeaderboardViewProps) {
  const t = TRANSLATIONS[lang];
  
  // Sort by highest earnings
  const sortedUsers = [...leaderboard].sort((a, b) => b.totalWon - a.totalWon);

  return (
    <div className="flex flex-col gap-6" id="leaderboard_view_container">
      {/* HEADER BANNER CARDS */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6" id="lead_intro_banner">
        <div className="flex items-center gap-4 text-center md:text-left">
          <div className="p-4 bg-yellow-500/10 text-yellow-400 rounded-2xl border border-yellow-500/20">
            <Trophy className="w-10 h-10 animate-bounce" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white">
              {lang === "bn" ? "সেরা গেমারস লিডারবোর্ড" : "Elite Gamers Leaderboard"}
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-md">
              {lang === "bn" 
                ? "আমাদের প্ল্যাটফর্মের সেরা ইন-গেম প্লেয়ার ও তাদের সর্বমোট টুর্নামেন্ট জয়ের তালিকা। আজই জয়েন করে নিজের স্থান করে নিন!"
                : "The Hall of Fame showcasing leading active players ranked by overall competitive tournament prize earnings."
              }
            </p>
          </div>
        </div>

        <div className="bg-slate-950 px-5 py-4 border border-slate-800 rounded-xl flex items-center gap-3">
          <Flame className="w-6 h-6 text-orange-500 fill-orange-500/30 animate-pulse" />
          <div className="text-right">
            <div className="text-xs text-slate-400 font-mono">
              {lang === "bn" ? "মোট সক্রিয় গেমার" : "Active Competitors"}
            </div>
            <div className="text-base font-extrabold text-white font-mono">
              +{sortedUsers.length * 15}
            </div>
          </div>
        </div>
      </div>

      {/* LEADERBOARD DATA TABLE GRID */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
        
        {/* Table Headings */}
        <div className="grid grid-cols-12 gap-3 p-4 bg-slate-950 border-b border-slate-800/80 text-[10px] font-mono tracking-widest text-slate-400 uppercase font-bold text-center">
          <div className="col-span-2 text-left">{lang === "bn" ? "র‍্যাংক" : "Rank"}</div>
          <div className="col-span-4 text-left">{lang === "bn" ? "প্লেয়ার নেম (IGN)" : "Gamer Tag (IGN)"}</div>
          <div className="col-span-2">{lang === "bn" ? "ম্যাচ খেলা" : "Matches"}</div>
          <div className="col-span-2">{lang === "bn" ? "মোট কিল" : "Total Kills"}</div>
          <div className="col-span-2 text-right text-yellow-400">{lang === "bn" ? "সর্বমোট জয়" : "Total Won"}</div>
        </div>

        <div className="divide-y divide-slate-800/60 font-mono">
          {sortedUsers.map((player, idx) => {
            const isTop3 = idx < 3;
            const rankColors = [
              "bg-yellow-400 text-slate-950",
              "bg-slate-300 text-slate-950",
              "bg-amber-600 text-white"
            ];
            
            return (
              <div 
                key={player.gamertag}
                className={`grid grid-cols-12 gap-3 items-center p-4 text-xs transition duration-200 hover:bg-slate-950/40 ${
                  idx === 0 ? "bg-yellow-500/5" : ""
                }`}
                id={`lead_row_player_${idx}`}
              >
                
                {/* RANK NUMBER COLS */}
                <div className="col-span-2 flex items-center gap-2">
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs ${
                    isTop3 ? rankColors[idx] : "bg-slate-800 text-slate-400"
                  }`}>
                    {idx + 1}
                  </span>
                  
                  {isTop3 && <TrendingUp className="w-3.5 h-3.5 text-indigo-400 hidden sm:inline" />}
                </div>

                {/* GAMERTAG COLS */}
                <div className="col-span-4 flex items-center gap-2 text-left font-sans font-bold text-white">
                  {idx === 0 && <Award className="w-4 h-4 text-yellow-400 flex-shrink-0" />}
                  <span className="truncate max-w-[150px]">{player.gamertag}</span>
                </div>

                {/* MATCHES PLAYED */}
                <div className="col-span-2 text-center text-slate-300">
                  <span className="flex items-center justify-center gap-1">
                    <Swords className="w-3.5 h-3.5 text-slate-500" />
                    {player.matchesPlayed}
                  </span>
                </div>

                {/* TOTAL KILLS */}
                <div className="col-span-2 text-center text-slate-300">
                  <span className="flex items-center justify-center gap-1">
                    {player.totalKills > 0 ? (
                      <>
                        <Target className="w-3.5 h-3.5 text-red-500" />
                        {player.totalKills}
                      </>
                    ) : (
                      <span className="text-slate-600">-</span>
                    )}
                  </span>
                </div>

                {/* TOTAL EARNINGS */}
                <div className="col-span-2 text-right text-yellow-400 font-extrabold text-xs sm:text-sm font-mono flex items-center justify-end gap-1">
                  🪙 {player.totalWon}
                </div>

              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
