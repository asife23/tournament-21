import React, { useState } from "react";
import { UserWallet, Transaction } from "../types";
import { TRANSLATIONS } from "../data";
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Smartphone, 
  Coins,
  History,
  AlertCircle
} from "lucide-react";

interface WalletViewProps {
  wallet: UserWallet;
  onAddTransaction: (trx: Transaction) => void;
  lang: "bn" | "en";
}

export default function WalletView({ wallet, onAddTransaction, lang }: WalletViewProps) {
  const t = TRANSLATIONS[lang];
  const [provider, setProvider] = useState<"bKash" | "Nagad" | "Rocket">("bKash");
  const [amount, setAmount] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [trxId, setTrxId] = useState<string>("");
  const [isDeposit, setIsDeposit] = useState<boolean>(true);
  
  const [successMsg, setSuccessMsg] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState<string>("");

  const handleAction = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    const parsedAmt = parseFloat(amount);
    if (isNaN(parsedAmt) || parsedAmt <= 0) {
      setErrorMsg(lang === "bn" ? "সঠিক কায়েন সংখ্যা লিখুন!" : "Please enter a valid coin amount!");
      return;
    }

    if (!phone || phone.length < 11) {
      setErrorMsg(lang === "bn" ? "দয়া করে সঠিক ১১ ডিজিটের মোবাইল নাম্বার দিন!" : "Please enter a valid 11-digit mobile number!");
      return;
    }

    if (isDeposit) {
      if (!trxId || trxId.trim().length < 6) {
        setErrorMsg(lang === "bn" ? "সঠিক ট্রানজেকশন আইডি (TrxID) লিখুন!" : "Please enter a valid Transaction ID!");
        return;
      }

      // Create Deposit Transaction (Pending)
      const newTrx: Transaction = {
        id: `trx-${Date.now()}`,
        type: "Deposit",
        amount: parsedAmt,
        method: provider,
        number: phone,
        trxId: trxId.trim().toUpperCase(),
        status: "Pending",
        date: new Date().toLocaleDateString(lang === "bn" ? "bn-BD" : "en-US", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      };

      onAddTransaction(newTrx);
      setSuccessMsg(lang === "bn" ? "🎉 কয়েন রিকোয়েস্ট পাঠানো হয়েছে! অনুগ্রহ করে এডমিনের অনুমোদনের জন্য অপেক্ষা করুন।" : "🎉 Coin load request submitted! Admin will approve shortly.");
    } else {
      // Withdraw logic
      if (parsedAmt > wallet.balance) {
        setErrorMsg(lang === "bn" ? "❌ দুঃখিত! আপনার একাউন্টে পর্যাপ্ত কয়েন নেই।" : "❌ Insufficient coins in wallet.");
        return;
      }

      // Create Withdraw Transaction (Pending)
      const newTrx: Transaction = {
        id: `trx-${Date.now()}`,
        type: "Withdraw",
        amount: parsedAmt,
        method: provider,
        number: phone,
        status: "Pending",
        date: new Date().toLocaleDateString(lang === "bn" ? "bn-BD" : "en-US", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      };

      onAddTransaction(newTrx);
      setSuccessMsg(lang === "bn" ? "🎉 কয়েন রিডিম রিকোয়েস্ট পাঠানো হয়েছে! অনুগ্রহ করে প্রসেসিং হওয়ার জন্য অপেক্ষা করুন।" : "🎉 Coins redemption request submitted! Processing soon.");
    }

    // Reset fields
    setAmount("");
    setPhone("");
    setTrxId("");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="wallet_view_container">
      {/* LEFT 5 COLS: WALLET STATS & TRANSACTION FORM */}
      <div className="lg:col-span-5 flex flex-col gap-6">
        
        {/* WALLET BALANCE CARD */}
        <div className="bg-gradient-to-br from-indigo-900/50 via-slate-900 to-slate-950 p-6 rounded-2xl border border-indigo-500/35 shadow-lg shadow-indigo-950/40 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl"></div>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-indigo-600/20 text-indigo-400 rounded-xl border border-indigo-500/20">
              <Wallet className="w-6 h-6 text-yellow-400 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                {lang === "bn" ? "মাই একাউন্ট ওয়ালেট" : "My Account Wallet"}
              </h2>
              <div className="text-3xl font-black text-white font-mono flex items-center gap-1.5 mt-1">
                🪙 {wallet.balance} <span className="text-xs text-indigo-300 font-normal font-sans">{lang === "bn" ? "কয়েন" : "Coins"}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-800/60 mt-4">
            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/50 flex flex-col">
              <span className="text-[10px] text-slate-400 font-mono tracking-wide uppercase flex items-center gap-1">
                <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                {t.deposit}
              </span>
              <span className="text-base font-bold text-emerald-400 mt-1 font-mono">🪙 {wallet.deposit}</span>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/50 flex flex-col">
              <span className="text-[10px] text-slate-400 font-mono tracking-wide uppercase flex items-center gap-1">
                <ArrowDownLeft className="w-3.5 h-3.5 text-amber-400" />
                {t.winning}
              </span>
              <span className="text-base font-bold text-amber-400 mt-1 font-mono">🪙 {wallet.winning}</span>
            </div>
          </div>
        </div>

        {/* RECHARGE / WITHDRAW FORM */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col">
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 mb-5">
            <button
              onClick={() => {
                setIsDeposit(true);
                setErrorMsg("");
                setSuccessMsg("");
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                isDeposit 
                  ? "bg-indigo-600 text-white" 
                  : "text-slate-400 hover:text-white"
              }`}
            >
              📥 {t.addMoney}
            </button>
            <button
              onClick={() => {
                setIsDeposit(false);
                setErrorMsg("");
                setSuccessMsg("");
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                !isDeposit 
                  ? "bg-amber-600 text-white" 
                  : "text-slate-400 hover:text-white"
              }`}
            >
              📤 {t.withdraw}
            </button>
          </div>

          <form onSubmit={handleAction} className="flex flex-col gap-4">
            
            {/* GATEWAY MOBILE PROVIDER BUTTONS */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-widest mb-2">
                {t.selectProvider}
              </label>
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { id: "bKash" as const, color: "hover:border-pink-500 bg-pink-500/10 text-pink-400 border-pink-500/20 active:bg-pink-600" },
                  { id: "Nagad" as const, color: "hover:border-orange-500 bg-orange-500/10 text-orange-400 border-orange-500/20 active:bg-orange-600" },
                  { id: "Rocket" as const, color: "hover:border-violet-500 bg-violet-500/10 text-violet-400 border-violet-500/20 active:bg-violet-600" }
                ].map((prov) => (
                  <button
                    key={prov.id}
                    type="button"
                    onClick={() => setProvider(prov.id)}
                    className={`p-2.5 rounded-xl border text-xs font-black transition-all flex items-center justify-center gap-1 cursor-pointer ${
                      provider === prov.id
                        ? "border-indigo-500 bg-indigo-500/20 text-white font-extrabold"
                        : "bg-slate-950 border-slate-800 text-slate-400"
                    } ${prov.color}`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    {prov.id}
                  </button>
                ))}
              </div>
            </div>

            {/* INSTRUCTION DETAILBOX */}
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 text-[11px] leading-relaxed text-slate-300">
              {isDeposit ? t.sendMoneyInstruct : t.sendMoneyWithdraw}
            </div>

            {/* AMOUNT INPUT */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {lang === "bn" ? "কয়েন এর পরিমাণ (এমাউন্ট)" : "Amount (Coins)"}
              </label>
              <div className="relative">
                <Coins className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                <input
                  type="number"
                  required
                  placeholder={lang === "bn" ? "যেমন: ৫০ বা ১০০" : "e.g., 50 or 100"}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>
            </div>

            {/* PHONE NUMBER INPUT */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.enterNumber} ({provider})
              </label>
              <input
                type="tel"
                required
                placeholder="017XXXXXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>

            {/* TRANSACTION ID (DEPOSIT ONLY) */}
            {isDeposit && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {t.trxIdLabel}
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., 9KFH8H4D3L"
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>
            )}

            {/* ERROR AND SUCCESS ALERT BOXES */}
            {errorMsg && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <p>{errorMsg}</p>
              </div>
            )}

            {successMsg && (
              <div className="bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 p-3 rounded-xl text-[11px] leading-relaxed">
                {successMsg}
              </div>
            )}

            <button
              type="submit"
              className={`w-full py-3 px-4 rounded-xl text-xs font-bold text-white tracking-wide shadow-md transition-all duration-200 cursor-pointer ${
                isDeposit 
                  ? "bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/15" 
                  : "bg-amber-600 hover:bg-amber-500 shadow-amber-600/15"
              }`}
            >
              {isDeposit ? t.confirmDeposit : t.confirmWithdraw}
            </button>

          </form>
        </div>

      </div>

      {/* RIGHT 7 COLS: TRANSACTION HISTORY LOGS */}
      <div className="lg:col-span-7 flex flex-col gap-4">
        <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2 mb-1">
          <History className="w-4 h-4 text-emerald-400 animate-pulse" />
          {t.trxHistory} ({wallet.transactions.length})
        </h2>

        {wallet.transactions.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-12 text-center text-slate-500 flex flex-col items-center justify-center">
            <Coins className="w-12 h-12 text-slate-700 mb-3" />
            <p className="text-sm">{t.noTrx}</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3 max-h-[580px] overflow-y-auto pr-1">
            {[...wallet.transactions].reverse().map((trx) => {
              const isPlus = trx.type === "Deposit" || trx.type === "Winning";
              return (
                <div 
                  key={trx.id}
                  className="bg-slate-900 border border-slate-800/80 rounded-xl p-4 flex items-center justify-between shadow-sm hover:border-slate-700/80 transition-all duration-200"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl ${
                      isPlus
                        ? "bg-emerald-500/10 text-emerald-400"
                        : "bg-rose-500/10 text-rose-400"
                    }`}>
                      {isPlus ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
                    </div>

                    <div className="flex flex-col gap-0.5">
                      <div className="text-xs font-semibold text-white flex items-center gap-2">
                        {lang === "bn" 
                          ? (trx.type === "Deposit" ? "কয়েন লোড (ডিপোজিট)" : trx.type === "Withdraw" ? "কয়েন রিডিম (উইথড্র)" : trx.type === "Entry Fee" ? "এন্ট্রি ফি (কয়েন)" : "ম্যাচ জয়ী কয়েন")
                          : (trx.type === "Deposit" ? "Add Coins" : trx.type === "Withdraw" ? "Redeem Coins" : trx.type === "Entry Fee" ? "Entry Fee" : "Winnings Paid")
                        }
                        {trx.method && (
                          <span className="text-[10px] bg-slate-950 px-1.5 py-0.5 rounded text-slate-400">
                            {trx.method}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {trx.date}
                      </span>
                      {trx.trxId && (
                        <span className="text-[10px] text-slate-400 font-mono">
                          TrxID: <span className="text-indigo-400">{trx.trxId}</span>
                        </span>
                      )}
                      {trx.number && (
                        <span className="text-[9px] text-slate-400 font-mono">
                          Num/UID: {trx.number}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1.5">
                    <span className={`text-sm font-extrabold font-mono ${isPlus ? "text-emerald-400" : "text-rose-400"}`}>
                      {isPlus ? "+" : "-"}{trx.amount} {lang === "bn" ? "কয়েন" : "Coins"}
                    </span>

                    {/* STATUS BADGES */}
                    <span className={`text-[9px] font-mono font-bold tracking-wider px-2 py-0.5 rounded-full flex items-center gap-1 ${
                      trx.status === "Approved"
                        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                        : trx.status === "Rejected"
                        ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                        : "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                    }`}>
                      {trx.status === "Approved" && <CheckCircle2 className="w-2.5 h-2.5" />}
                      {trx.status === "Rejected" && <XCircle className="w-2.5 h-2.5" />}
                      {trx.status === "Pending" && <Clock className="w-2.5 h-2.5 animate-spin" />}
                      {lang === "bn" 
                        ? (trx.status === "Approved" ? "অনুমোদিত" : trx.status === "Rejected" ? "বাতিল" : "অপেক্ষমান")
                        : trx.status
                      }
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
